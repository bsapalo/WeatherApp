DROP DATABASE IF EXISTS userSearches;
CREATE DATABASE userSearches;
USE userSearches;

CREATE TABLE userInfo(
    usernames VARCHAR(50) PRIMARY KEY NOT NULL,
    passwords VARCHAR(50) NOT NULL
);

CREATE TABLE userSearches(
	searchID INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    searchValue VARCHAR(50) NOT NULL,
    searchTime VARCHAR(50) NOT NULL,
    usernames VARCHAR(50) NOT NULL,
    FOREIGN KEY (usernames) REFERENCES userInfo(usernames)
);
