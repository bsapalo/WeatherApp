package classes;

import java.util.Comparator;

public class TempLowDescendingComparator implements Comparator<POJOs.List> {

	@Override
	public int compare(POJOs.List w0, POJOs.List w1) {
		return (int) (w1.getMain().getTempMin() - w0.getMain().getTempMin());
	}
	
}
