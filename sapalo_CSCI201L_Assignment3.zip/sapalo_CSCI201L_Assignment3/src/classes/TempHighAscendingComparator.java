package classes;

import java.util.Comparator;

public class TempHighAscendingComparator implements Comparator<POJOs.List> {

	@Override
	public int compare(POJOs.List w0, POJOs.List w1) {
		return (int) (w0.getMain().getTempMax() - w1.getMain().getTempMax());
	}

}	
