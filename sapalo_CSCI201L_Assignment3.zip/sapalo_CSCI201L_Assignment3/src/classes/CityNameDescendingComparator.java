package classes;

import java.util.Comparator;

public class CityNameDescendingComparator implements Comparator<POJOs.List> {

	@Override
	public int compare(POJOs.List w0, POJOs.List w1) {
		return w0.getName().compareTo(w1.getName()) * -1;
	}

}
