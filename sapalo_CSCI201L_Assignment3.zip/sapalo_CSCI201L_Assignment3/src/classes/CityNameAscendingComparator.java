package classes;

import java.util.Comparator;

public class CityNameAscendingComparator implements Comparator<POJOs.List> {

	@Override
	public int compare(POJOs.List w0, POJOs.List w1) {
		return w0.getName().compareTo(w1.getName());
	}

}
