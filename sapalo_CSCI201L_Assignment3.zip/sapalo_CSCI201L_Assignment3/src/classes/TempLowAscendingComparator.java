package classes;

import java.util.Comparator;

public class TempLowAscendingComparator implements Comparator<POJOs.List> {

	@Override
	public int compare(POJOs.List w0, POJOs.List w1) {
		return (int) (w0.getMain().getTempMin() - w1.getMain().getTempMin());
	}

}
