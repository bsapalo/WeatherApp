package server;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class RegisterUserServlet
 */
@WebServlet("/RegisterUserServlet")
public class RegisterUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		//pull all the data
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");
		System.out.println(username);
		System.out.println(password);
		System.out.println(password2);
		//create objects
		Boolean taken = false;
		Boolean noMatch = false;
		Boolean loggedIn = false;
		//check if passwords match
		if(!password.equals(password2)) noMatch = true;
		//establish connection
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/userSearches?user=root&password=brandon8");
			ps = conn.prepareStatement("SELECT * FROM userInfo WHERE usernames=?");
			ps.setString(1, username);
			rs = ps.executeQuery();
			if(rs.next() || noMatch) {
				//user already exists or the passwords didnt match
				//so don't add to database
				taken = true;
			}
			else {
				//insert a new username and password into the database
				ps = conn.prepareStatement("INSERT INTO userInfo(usernames, passwords) VALUES (?,?)");
				ps.setString(1, username);
				ps.setString(2, password);
				ps.executeUpdate();
			}
		} catch (SQLException sqle) {
			System.out.print("sqle: "+sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.print("cnfe: "+cnfe.getMessage());
		} finally {
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(conn != null) conn.close();
			} catch(SQLException sqle) {
				System.out.println("sqle closing stuff: " + sqle.getMessage());
			}
		}
		
		//redirect back if error
		if(taken || noMatch) {
			session.setAttribute("taken", taken);
			session.setAttribute("noMatch", noMatch);
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/Register.jsp");
			dispatch.forward(request, response);
		}
		else {
			loggedIn = true;
			session.setAttribute("user", username);
			session.setAttribute("loggedIn", loggedIn);
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/Home.jsp");
			dispatch.forward(request, response);
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
}
