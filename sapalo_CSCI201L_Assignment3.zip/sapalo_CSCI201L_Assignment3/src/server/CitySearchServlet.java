package server;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import classes.CityNameAscendingComparator;
import classes.CityNameDescendingComparator;
import classes.TempHighAscendingComparator;
import classes.TempHighDescendingComparator;
import classes.TempLowAscendingComparator;
import classes.TempLowDescendingComparator;
import classes.Weather;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import POJOs.CityData;
import POJOs.Example;

@WebServlet("/CitySearchServlet")
public class CitySearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	ParseCitiesJSON.parseJSON();
    	HttpSession session = request.getSession();
    	//get the search queries
    	ArrayList<POJOs.List> cityList = null;
    	POJOs.List cityPOJO = null;
    	String city = request.getParameter("city");
    	String lat = request.getParameter("latitude");
    	String lon = request.getParameter("longitude");
    	
    	System.out.println(city);
    	System.out.println(lat);
    	System.out.println(lon);
    	
    	//get the list of CityID's that match the query sent
    	if((city.equals("") || city.equals(null))&&(lat.equals("") || lat.equals(null))&&(lon.equals("") || lon.equals(null))) {
    		cityList = null;
    		cityPOJO = null;
    		session.setAttribute("cityList", cityList);
        	session.setAttribute("cityPOJO", cityPOJO);
    	}
    	else if(city==null || city.equals("")) {
    		//this will be null if no city matches the query
    		WeatherAPIConnection.connectToWeatherAPI(lat, lon);
    		cityPOJO = WeatherAPIConnection.cityPOJO;
        	//create a new attribute to be accessed by Result.jsp
        	session.setAttribute("cityPOJO", cityPOJO);
    	}
    	else {
    		//this will be null if no city matches the query
    		WeatherAPIConnection.connectToWeatherAPI(city, null);
    		cityList = (ArrayList<POJOs.List>) WeatherAPIConnection.matchedCities;
        	//create a new attribute to be accessed by Result.jsp
        	session.setAttribute("cityList", cityList);
    	}
    	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    	//SORTING
    	
    	ArrayList<POJOs.List> nameasc = new ArrayList<POJOs.List>();
    	ArrayList<POJOs.List> namedes = new ArrayList<POJOs.List>();
    	ArrayList<POJOs.List> templowasc = new ArrayList<POJOs.List>();
    	ArrayList<POJOs.List> templowdes = new ArrayList<POJOs.List>();
    	ArrayList<POJOs.List> temphighasc = new ArrayList<POJOs.List>();
    	ArrayList<POJOs.List> temphighdes = new ArrayList<POJOs.List>();
    	
    	if(cityList != null) {
	    	Collections.sort(cityList, new CityNameAscendingComparator());
	    	for(POJOs.List w : cityList) {
	    		nameasc.add(w);
	    	}
	    	Collections.sort(cityList, new CityNameDescendingComparator());
	    	for(POJOs.List w : cityList) {
	    		namedes.add(w);
	    	}
	    	Collections.sort(cityList, new TempLowAscendingComparator());
	    	for(POJOs.List w : cityList) {
	    		templowasc.add(w);
	    	}
	    	Collections.sort(cityList, new TempLowDescendingComparator());
	    	for(POJOs.List w : cityList) {
	    		templowdes.add(w);
	    	}
	    	Collections.sort(cityList, new TempHighAscendingComparator());
	    	for(POJOs.List w : cityList) {
	    		temphighasc.add(w);
	    	}
	    	Collections.sort(cityList, new TempHighDescendingComparator());
	    	for(POJOs.List w : cityList) {
	    		temphighdes.add(w);
	    	}
    	}
    	else if(cityPOJO != null){
    		nameasc.add(cityPOJO);
    	}
    	
    	session.setAttribute("nameasc", nameasc);
    	session.setAttribute("namedes", namedes);
    	session.setAttribute("templowasc", templowasc);
    	session.setAttribute("templowdes", templowdes);
    	session.setAttribute("temphighasc", temphighasc);
    	session.setAttribute("temphighdes", temphighdes);
    	
    	RequestDispatcher rd = request.getRequestDispatcher("/Results.jsp");
    	rd.forward(request, response);
    }
}
