package server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import classes.CityNameAscendingComparator;
import classes.CityNameDescendingComparator;
import classes.TempHighAscendingComparator;
import classes.TempHighDescendingComparator;
import classes.TempLowAscendingComparator;
import classes.TempLowDescendingComparator;
import classes.Weather;

@WebServlet("/LatLongSearchServlet")
public class LatLongSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ParseCitiesJSON.parseJSON();
		System.out.println("In latlong search servelet");
    	//get the search queries
    	ArrayList<POJOs.List> cityList;
    	POJOs.List cityPOJO;
    	String city = request.getParameter("city");
    	String lat = request.getParameter("latitude");
    	String lon = request.getParameter("longitude");
    	//get the list of CityID's that match the query sent
    	if((city.equals("") || city.equals(null))&&(lat.equals("") || lat.equals(null))&&(lon.equals("") || lon.equals(null))) {
    		System.out.println("In latlong search servelet NULL");
    		cityList = null;
    	}
    	else {
    		//this will be null if no city matches the query
    		cityPOJO = WeatherAPIConnection.cityPOJO;
    		HttpSession session = request.getSession();
        	//create a new attribute to be accessed by Result.jsp
        	session.setAttribute("cityPOJO", cityPOJO);
    	}
    	
    	RequestDispatcher rd = request.getRequestDispatcher("/Results.jsp");
    	rd.forward(request, response);
    }
}
