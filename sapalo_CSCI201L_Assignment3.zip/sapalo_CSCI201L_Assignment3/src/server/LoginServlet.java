package server;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		//pull all the data
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Boolean loggedIn = false;
		Boolean incorrectUser = true;
		Boolean incorrectPass = true;
		//establish connection
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/userSearches?user=root&password=brandon8");
			ps = conn.prepareStatement("SELECT * FROM userInfo WHERE usernames=? AND passwords=?");
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if(rs.next()) {
				incorrectUser = false;
				incorrectPass = false;
			}
		} catch (SQLException sqle) {
			System.out.print("sqle: "+sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.print("cnfe: "+cnfe.getMessage());
		} finally {
			try {
				if(rs != null) rs.close();
				if(ps != null) ps.close();
				if(conn != null) conn.close();
			} catch(SQLException sqle) {
				System.out.println("sqle closing stuff: " + sqle.getMessage());
			}
		}
		//create statements to display errors on page
		String incorrectUserStmnt = "Invalid Username";
		String incorrectPassStmnt = "Invalid Password";
		
		session.setAttribute("userError", incorrectUser);
		session.setAttribute("incorrectUserStmnt", incorrectUserStmnt);
		session.setAttribute("passError", incorrectPass);
		session.setAttribute("incorrectPassStmnt", incorrectPassStmnt);
		//if no errors, direct to next page
		if(!incorrectUser && !incorrectPass) {
			loggedIn = true;
			session.setAttribute("user", username);
			session.setAttribute("loggedIn", loggedIn);
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/Home.jsp");
			dispatch.forward(request, response);
		}
		else {
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/Login.jsp");
			dispatch.forward(request, response);
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
}
