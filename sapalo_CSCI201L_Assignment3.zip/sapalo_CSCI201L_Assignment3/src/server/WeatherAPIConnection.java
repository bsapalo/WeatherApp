package server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import POJOs.CityData;
import POJOs.Example;
import sun.net.www.URLConnection;

/**
 * Servlet implementation class ApiConnection
 */
@WebServlet("/WeatherAPIConnection")
public class WeatherAPIConnection extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static List<POJOs.List> matchedCities;
	public static POJOs.List cityPOJO;
	
	public static void connectToWeatherAPI(String query1, String query2) throws IOException {
		boolean coordSearch = false;
		//preliminary start of the string
		String myURL = "";
		ArrayList<Integer> listID = new ArrayList<Integer>();
		//add the ID's from the list separated by commas
		if(query2 == null) { 
			listID.addAll(MakeJsonCitiesObjects.getMatchingCityIDs(query1));
			myURL = "https://api.openweathermap.org/data/2.5/group?id=";
		}
		else {
			coordSearch = true;
			myURL = "https://api.openweathermap.org/data/2.5/weather?lat=" 
			+ query1 + "&lon=" + query2 + "&appid=bf905d6bbb7ef5e4d2664ceb317d00f1";
			listID.addAll(MakeJsonCitiesObjects.getMatchingCityIDs(query1));
		}
		
		//make the API call
		if(listID.size() !=0 ) {
			//iterate over the ID's to add to URL
			for(int i=0; i<listID.size(); i++) {
				if(i == 20) break;
				myURL += listID.get(i).toString();
				if(i!=19 && i!=listID.size()-1) myURL += ",";
			}
			//add the API key to the string
			myURL += "&units=metric&appid=bf905d6bbb7ef5e4d2664ceb317d00f1";
	        URL weatherURL = new URL(myURL);
	        StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example cityPOJO = gson.fromJson(list.toString(), Example.class);
	        WeatherAPIConnection.matchedCities = cityPOJO.getList();
		}
		else if(coordSearch) {
			URL weatherURL = new URL(myURL);
	        StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        WeatherAPIConnection.cityPOJO = gson.fromJson(list.toString(), POJOs.List.class);
		}
		else {
			WeatherAPIConnection.matchedCities = null;
		}
	}
}
