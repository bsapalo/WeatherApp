package server;
import java.util.ArrayList;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet("/MakeJsonCities")
public class MakeJsonCitiesObjects extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public static ArrayList<Integer> getMatchingCityIDs(String name) {
		ArrayList<Integer> myList = new ArrayList<Integer>();
		for(int i=0; i<ParseCitiesJSON.data.size(); i++) {
			if(ParseCitiesJSON.data.get(i).getName().equals(name)) {
				myList.add(ParseCitiesJSON.data.get(i).getId());
			}
		}
		return myList;
	}
	
	public static ArrayList<Integer> getMatchingCityIDs(String lat, String lon){
		ArrayList<Integer> myList = new ArrayList<Integer>();
		Double mylat = Double.parseDouble(lat);
		Double mylon = Double.parseDouble(lon);
		for(int i=0; i<ParseCitiesJSON.data.size(); i++) {
			if(ParseCitiesJSON.data.get(i).getCoord().getLat().compareTo(mylat) == 0
					&& ParseCitiesJSON.data.get(i).getCoord().getLon().compareTo(mylon) == 0) {
				myList.add(ParseCitiesJSON.data.get(i).getId());
			}
		}
		return myList;
	}
}
