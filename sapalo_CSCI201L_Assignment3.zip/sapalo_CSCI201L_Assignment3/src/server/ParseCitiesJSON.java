package server;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import POJOs.CityData;

@WebServlet("/ParseCitiesJSON")
public class ParseCitiesJSON extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static List<CityData> data;
	
	public static void parseJSON() {
		//need to place the reader in a try/catch block
		try {
			//create a file reader
			FileReader fr = new FileReader("/Users/b_reel/eclipse-workspace/sapalo_CSCI201L_Assignment3/city.list.json");
			//buffered reader allows you to take in lines
			BufferedReader br = new BufferedReader(fr);
			//reads in a line
			String line = br.readLine();
			StringBuilder list = new StringBuilder();
			//loop until there is nothing left in the file
			while(line != null) {
				list.append(line);
				line = br.readLine();
			}
			//makes the GSON objects
			Gson gson = new Gson();
			Type listType = new TypeToken<List<CityData>>(){}.getType();
			data = gson.fromJson(list.toString(), listType);
			//close the file reader
			br.close();
			fr.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("fnfe: " + fnfe.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
}
