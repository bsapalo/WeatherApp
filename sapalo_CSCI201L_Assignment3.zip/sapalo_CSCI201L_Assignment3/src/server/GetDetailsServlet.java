package server;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import classes.Weather;

@WebServlet("/GetDetailsServlet")
public class GetDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ID = request.getParameter("id");
		HttpSession session = request.getSession();
		ArrayList<POJOs.List> cities = (ArrayList<POJOs.List>) session.getAttribute("cityList");
		POJOs.List cityPOJO = (POJOs.List) session.getAttribute("cityPOJO");
	
		POJOs.List w = null;
		if(ID != null && cities!=null) {
			for(POJOs.List listObject: cities) {
				if(listObject.getId().toString().equals(ID)) {
					w = listObject;
				}
			}
		}
		else {
			w = cityPOJO;
		}
		
		session.setAttribute("city", w);
		//direct to next page
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/Details.jsp");
		dispatch.forward(request, response);
	}
}
